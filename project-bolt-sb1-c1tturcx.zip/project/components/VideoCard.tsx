import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { Heart, MessageCircle, Bookmark } from 'lucide-react-native';

const { height } = Dimensions.get('window');

interface VideoCardProps {
  video: {
    title: string;
    author: string;
    likes: number;
    subject: string;
  };
}

export default function VideoCard({ video }: VideoCardProps) {
  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <View style={styles.placeholder}>
          <Text style={styles.placeholderText}>Video Preview</Text>
        </View>
      </View>
      <View style={styles.sidebar}>
        <View style={styles.sidebarButton}>
          <Heart color="white" size={28} />
          <Text style={styles.sidebarText}>{video.likes}</Text>
        </View>
        <View style={styles.sidebarButton}>
          <MessageCircle color="white" size={28} />
          <Text style={styles.sidebarText}>Comments</Text>
        </View>
        <View style={styles.sidebarButton}>
          <Bookmark color="white" size={28} />
          <Text style={styles.sidebarText}>Save</Text>
        </View>
      </View>
      <View style={styles.info}>
        <Text style={styles.title}>{video.title}</Text>
        <Text style={styles.author}>@{video.author}</Text>
        <Text style={styles.subject}>#{video.subject}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: height - 49,
    backgroundColor: '#000',
    position: 'relative',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeholder: {
    width: '100%',
    height: '100%',
    backgroundColor: '#222',
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeholderText: {
    color: '#666',
    fontSize: 18,
  },
  sidebar: {
    position: 'absolute',
    right: 8,
    bottom: 100,
    alignItems: 'center',
  },
  sidebarButton: {
    alignItems: 'center',
    marginVertical: 8,
  },
  sidebarText: {
    color: 'white',
    fontSize: 12,
    marginTop: 4,
  },
  info: {
    position: 'absolute',
    left: 8,
    bottom: 20,
    right: 80,
    padding: 12,
  },
  title: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  author: {
    color: 'white',
    fontSize: 14,
    marginBottom: 4,
  },
  subject: {
    color: '#00ff00',
    fontSize: 14,
  },
});