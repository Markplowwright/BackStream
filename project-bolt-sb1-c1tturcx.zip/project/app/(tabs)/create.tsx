import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Video, Image, FileVideo } from 'lucide-react-native';

export default function CreateScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Create Content</Text>
      <View style={styles.optionsContainer}>
        <TouchableOpacity style={styles.option}>
          <Video size={32} color="white" />
          <Text style={styles.optionText}>Record Video</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.option}>
          <FileVideo size={32} color="white" />
          <Text style={styles.optionText}>Upload Video</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.option}>
          <Image size={32} color="white" />
          <Text style={styles.optionText}>Create Slides</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.draftsContainer}>
        <Text style={styles.sectionTitle}>Your Drafts</Text>
        <Text style={styles.emptyText}>No drafts yet</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    padding: 16,
  },
  title: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
  },
  optionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 32,
  },
  option: {
    alignItems: 'center',
    backgroundColor: '#222',
    padding: 16,
    borderRadius: 12,
    width: '30%',
  },
  optionText: {
    color: 'white',
    marginTop: 8,
    textAlign: 'center',
  },
  draftsContainer: {
    flex: 1,
  },
  sectionTitle: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  emptyText: {
    color: '#666',
    textAlign: 'center',
    marginTop: 32,
  },
});