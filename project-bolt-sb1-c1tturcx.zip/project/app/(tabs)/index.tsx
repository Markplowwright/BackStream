import { View, Text, StyleSheet, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import VideoCard from '@/components/VideoCard';

const DUMMY_VIDEOS = [
  {
    id: '1',
    title: 'Introduction to React Native',
    author: 'Jane Doe',
    likes: 1200,
    subject: 'Programming',
  },
  {
    id: '2',
    title: 'Basic Algebra Explained',
    author: 'John Smith',
    likes: 890,
    subject: 'Mathematics',
  },
];

export default function HomeScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={DUMMY_VIDEOS}
        renderItem={({ item }) => <VideoCard video={item} />}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
});