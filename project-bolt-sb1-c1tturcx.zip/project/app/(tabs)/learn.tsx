import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Trophy, Clock, BookOpen, Star } from 'lucide-react-native';

export default function LearnScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>My Learning</Text>
      <View style={styles.statsContainer}>
        <View style={styles.statItem}>
          <Trophy color="#FFD700" size={24} />
          <Text style={styles.statValue}>5</Text>
          <Text style={styles.statLabel}>Day Streak</Text>
        </View>
        <View style={styles.statItem}>
          <Clock color="#00ff00" size={24} />
          <Text style={styles.statValue}>2.5h</Text>
          <Text style={styles.statLabel}>This Week</Text>
        </View>
        <View style={styles.statItem}>
          <Star color="#ff4757" size={24} />
          <Text style={styles.statValue}>250</Text>
          <Text style={styles.statLabel}>Points</Text>
        </View>
      </View>
      <View style={styles.coursesContainer}>
        <Text style={styles.sectionTitle}>In Progress</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={styles.courseCard}>
            <BookOpen color="white" size={24} />
            <Text style={styles.courseTitle}>React Native Basics</Text>
            <Text style={styles.courseProgress}>Progress: 60%</Text>
          </View>
          <View style={styles.courseCard}>
            <BookOpen color="white" size={24} />
            <Text style={styles.courseTitle}>JavaScript Advanced</Text>
            <Text style={styles.courseProgress}>Progress: 30%</Text>
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    padding: 16,
  },
  title: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 32,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 4,
  },
  statLabel: {
    color: '#666',
    fontSize: 12,
  },
  coursesContainer: {
    flex: 1,
  },
  sectionTitle: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  courseCard: {
    backgroundColor: '#222',
    padding: 16,
    borderRadius: 12,
    marginRight: 12,
    width: 200,
  },
  courseTitle: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    marginVertical: 8,
  },
  courseProgress: {
    color: '#00ff00',
    fontSize: 14,
  },
});